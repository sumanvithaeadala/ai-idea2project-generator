# Calculator Web App

A lightweight, responsive web‑based calculator built with **HTML**, **CSS**, and **vanilla JavaScript**. The project demonstrates clean separation of concerns, modern CSS custom properties, and a fully‑featured calculator logic encapsulated in a reusable `Calculator` class.

---

## Table of Contents

1. [Project Overview](#project-overview)
2. [Features](#features)
3. [Tech Stack](#tech-stack)
4. [Installation](#installation)
5. [Usage](#usage)
6. [Development](#development)
7. [Contribution Guidelines](#contribution-guidelines)
8. [License](#license)

---

## Project Overview

The calculator consists of three core files:

- **`index.html`** – The markup that defines the UI layout.
- **`styles.css`** – Visual styling using CSS Grid, custom properties, and a mobile‑first responsive design.
- **`app.js`** – The business logic encapsulated in a `Calculator` class and the glue code that binds UI events (clicks & keyboard) to the class methods.

The HTML references the stylesheet and the script via:

```html
<link rel="stylesheet" href="styles.css">
<script defer src="app.js"></script>
```

The script runs after the DOM is parsed (`defer`), creates a global `Calculator` instance, and wires up all buttons and keyboard shortcuts.

---

## Features

- **Basic arithmetic** – addition, subtraction, multiplication, division.
- **Clear & backspace** – Reset the calculator or delete the last digit.
- **Keyboard support** – Numbers, `+ - * /`, `Enter`/`=`, `Backspace`, `Escape`.
- **Error handling** – Division by zero displays an `Error` message.
- **Responsive design** – Works on desktop and mobile (≤ 600 px).
- **CSS custom properties** – Easy theming via `--color-primary`, `--color-accent`, etc.
- **Modular code** – `Calculator` class can be imported or instantiated elsewhere for testing.

---

## Tech Stack

| Layer | Technology |
|-------|------------|
| Markup | HTML5 |
| Styling | CSS3 (Custom Properties, Grid, Media Queries) |
| Logic | Vanilla JavaScript (ES6 class) |
| Font | Google Fonts – **Roboto** |
| Build | No build step – run directly in the browser |

---

## Installation

1. **Clone the repository**
   ```bash
   git clone https://github.com/your‑username/calculator-webapp.git
   cd calculator-webapp
   ```
2. **Open the app**
   - Simply open `index.html` in any modern browser (Chrome, Firefox, Edge, Safari).
   - No server is required for basic use, but a local server can be started for development (see the *Development* section).

---

## Usage

### UI Interaction

| Control | Action |
|---------|--------|
| **Number buttons** (`0‑9`) | Append the digit to the current entry. |
| **Decimal (`.`) button** | Adds a decimal point (only one per number). |
| **Operator buttons** (`+ – * /`) | Store the current value and set the pending operator. |
| **Equals (`=`) button** | Compute the result of the pending operation. |
| **Clear (`C`) button** | Reset the calculator to its initial state. |
| **Backspace (⌫) button** | Delete the last character of the current entry. |

### Keyboard Shortcuts

| Key | Effect |
|-----|--------|
| `0‑9` / `.` | Same as clicking the corresponding digit button. |
| `+ - * /` | Set the operator. |
| `Enter` or `=` | Perform calculation (equals). |
| `Backspace` | Delete last digit. |
| `Escape` | Clear the calculator. |

### Error Messages

- **Division by zero** – The display shows `Error` for 1.5 seconds before automatically resetting.

---

## Development

### Running a Local Server

While the app works by opening `index.html` directly, using a local server avoids CORS warnings and provides a more realistic development environment.

```bash
# Using Python (built‑in)
python -m http.server 8000
# Then open http://localhost:8000 in your browser.
```

Or with **Node.js** and **http‑server**:

```bash
npm install -g http-server
http-server .
```

### Modifying Styles

- All colour values are defined as CSS custom properties in `styles.css` under the `:root` selector. Change `--color-primary`, `--color-accent`, etc., to re‑theme the app.
- Layout is driven by CSS Grid; you can adjust `grid-template-columns` or `gap` to change button spacing.
- For additional responsive breakpoints, add more `@media` rules.

### Modifying Logic

- The core calculator logic lives in `app.js` inside the `Calculator` class.
- To add new operations (e.g., exponentiation), extend the `calculate()` method and update the `setOperator()` mapping.
- Unit tests can be written against `window.Calculator` because the class is exposed globally.

### Project Structure

```
├── index.html      # Markup – UI layout
├── styles.css      # Styling – CSS custom properties & Grid
├── app.js          # Logic – Calculator class + event binding
└── README.md       # Documentation (this file)
```

---

## Code Snippets

### HTML Structure (`index.html`)

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calculator</title>
    <link rel="stylesheet" href="styles.css">
    <script defer src="app.js"></script>
</head>
<body>
    <div class="calculator" id="calculator">
        <input type="text" readonly class="calc-display" id="display" aria-label="Calculator display" />
        <div class="calc-buttons">
            <!-- Buttons use data-action / data-value attributes for JS binding -->
            <button id="clear" data-action="clear">C</button>
            <button id="backspace" data-action="backspace">⌫</button>
            <button id="divide" data-action="divide">/</button>
            <button id="multiply" data-action="multiply">*</button>
            <!-- ...remaining digit and operator buttons... -->
        </div>
    </div>
</body>
</html>
```

### CSS Variables (`styles.css` – root section)

```css
:root {
  /* Primary colour – used for most interactive elements */
  --color-primary: #4a90e2;
  /* Secondary colour – background of the calculator container */
  --color-secondary: #f5f7fa;
  /* Accent colour – hover / focus states */
  --color-accent: #357ab8;
  /* Text colour – ensures good contrast on primary backgrounds */
  --color-on-primary: #ffffff;
  /* Animation duration used for transitions */
  --animation-duration: 0.25s;
  /* Base font size – makes scaling easier */
  --base-font-size: 1rem;
}
```

### JavaScript Calculator Class (`app.js`)

```js
// Core Calculator implementation and UI binding
class Calculator {
  constructor() {
    this.currentInput = '';
    this.previousValue = null;
    this.operator = null;
    this.resetNext = false;
    this.updateDisplay();
  }

  /** Append a digit or decimal point to the current input. */
  appendDigit(digit) {
    if (this.resetNext) {
      this.currentInput = '';
      this.resetNext = false;
    }
    if (digit === '.' && this.currentInput.includes('.')) return;
    this.currentInput += digit;
    this.updateDisplay();
  }

  /** Set the operator (+, -, *, /). */
  setOperator(op) {
    if (this.currentInput === '' && this.previousValue === null) return;
    if (this.operator && !this.resetNext) this.calculate();
    if (this.currentInput !== '') this.previousValue = parseFloat(this.currentInput);
    this.operator = op;
    this.resetNext = true;
  }

  /** Perform the pending calculation. */
  calculate() {
    if (!this.operator || this.currentInput === '' || this.previousValue === null) return;
    const current = parseFloat(this.currentInput);
    let result;
    switch (this.operator) {
      case '+': result = this.previousValue + current; break;
      case '-': result = this.previousValue - current; break;
      case '*': result = this.previousValue * current; break;
      case '/':
        if (current === 0) { this.displayError(); return; }
        result = this.previousValue / current; break;
      default: return;
    }
    this.currentInput = result.toString();
    this.previousValue = null;
    this.operator = null;
    this.resetNext = true;
    this.updateDisplay();
  }

  /** Clear the calculator state. */
  clear() {
    this.currentInput = '';
    this.previousValue = null;
    this.operator = null;
    this.resetNext = false;
    this.updateDisplay();
  }

  /** Remove the last character from the current input. */
  backspace() {
    if (this.resetNext) { this.currentInput = ''; this.resetNext = false; }
    else { this.currentInput = this.currentInput.slice(0, -1); }
    this.updateDisplay();
  }

  /** Update the visual display element. */
  updateDisplay() {
    const display = document.getElementById('display');
    const text = this.currentInput || (this.previousValue !== null ? this.previousValue : '0');
    if (display) display.value = text;
  }

  /** Show an error message (e.g., division by zero). */
  displayError() {
    const display = document.getElementById('display');
    if (display) display.value = 'Error';
    setTimeout(() => this.clear(), 1500);
  }
}

// Expose globally for potential external use
window.Calculator = Calculator;
```

---

## Contribution Guidelines

1. **Fork the repository** and create a new branch for your feature or bug‑fix.
2. Follow the existing code style (ES6 classes, `const`/`let`, semicolons, and two‑space indentation).
3. **Update documentation** if you add new features or change existing behaviour.
4. Submit a **Pull Request** with a clear description of the changes.
5. Ensure the app still works by opening `index.html` (or via the local server) and testing all UI interactions.

---

## License

This project is licensed under the **MIT License** – see the `LICENSE` file for details.

---

## Screenshots

*Replace the placeholder paths with actual screenshots of the running app.*

![Calculator – Light Theme](path/to/screenshot-light.png)
![Calculator – Mobile View](path/to/screenshot-mobile.png)
