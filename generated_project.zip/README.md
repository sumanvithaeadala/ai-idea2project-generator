# ColorfulCalculator

**ColorfulCalculator** is a vibrant, web‑based calculator that uses color‑coded buttons to make arithmetic operations intuitive and fun. Built with plain HTML, CSS, and JavaScript, it runs directly in the browser—no build tools or server required.

---

## Tech Stack
- **HTML** – Structure of the calculator UI.
- **CSS** – Color‑coded styling and responsive layout.
- **JavaScript** – Core logic, keyboard shortcuts, and error handling.

![Screenshot Placeholder](path/to/screenshot.png)

---

## Setup
1. **Clone the repository**
   ```bash
   git clone https://github.com/your-username/ColorfulCalculator.git
   cd ColorfulCalculator
   ```
2. **Open the application**
   - Simply open `index.html` in any modern web browser (Chrome, Firefox, Edge, Safari). No build step, npm install, or server is required.

---

## Features
- **Color‑coded buttons** for numbers, operators, and functions.
- **Keyboard support** for all primary calculator actions.
- **Live evaluation** with immediate visual feedback.
- **Division‑by‑zero protection** – displays a clear error message.
- **Responsive design** – UI adapts gracefully to mobile and tablet widths.
- **Clear (C) and Delete (←)** functionality.

---

## Usage
### Button Layout & Color Coding
| Color | Buttons |
|-------|---------|
| ![#4CAF50](https://via.placeholder.com/15/4CAF50/000000?text=+) **Green** | Numbers `0‑9` and decimal `.` |
| ![#2196F3](https://via.placeholder.com/15/2196F3/000000?text=+) **Blue** | Operators `+`, `-`, `*`, `/` |
| ![#FF9800](https://via.placeholder.com/15/FF9800/000000?text=+) **Orange** | Equals `=` and `Enter` |
| ![#F44336](https://via.placeholder.com/15/F44336/000000?text=+) **Red** | Clear `C` and `Esc` |
| ![#9E9E9E](https://via.placeholder.com/15/9E9E9E/000000?text=+) **Gray** | Delete `←` (Backspace) |

### Keyboard Shortcuts
| Key | Action |
|-----|--------|
| `0‑9` | Input corresponding number |
| `.` | Input decimal point |
| `+` | Addition |
| `-` | Subtraction |
| `*` | Multiplication |
| `/` | Division |
| `Enter` or `=` | Evaluate expression |
| `Backspace` | Delete last character |
| `Esc` or `C` | Clear the current input |

---

## Error Handling
- **Division by zero** – When a division by zero is attempted, the calculator clears the current expression and displays the message **"Error: Division by zero"** in the display area. The user can then continue typing a new expression.

---

## Responsive Design
The layout uses CSS flexbox and media queries to ensure the calculator looks great on all devices:
- **Desktop** – Buttons are arranged in a grid with ample spacing.
- **Tablet & Mobile** – Buttons shrink and wrap to fit narrower viewports, while the display remains readable.

---

## Contribution
1. **Run a local development server** (optional, for live reload):
   ```bash
   # Using Python's built‑in server
   python -m http.server 8000
   # Then open http://localhost:8000 in your browser
   ```
2. **Linting suggestions**
   - Use an HTML linter (e.g., `htmlhint`) to keep markup clean.
   - Use a CSS linter (e.g., `stylelint`) for consistent styling.
   - Use ESLint for JavaScript—prefer `eslint:recommended` rules.
3. **Pull Requests** – Fork the repo, make your changes, and submit a PR. Ensure the UI remains functional across browsers and that the README stays up‑to‑date.

---

## License
[MIT License](LICENSE) – *Placeholder – replace with your preferred license.*
