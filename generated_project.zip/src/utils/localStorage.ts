// Utility functions for persisting todos in localStorage

import { Todo } from "../types";

/**
 * Load the list of todos from the browser's localStorage.
 * If no data is stored yet, an empty array is returned.
 */
export const loadTodos = (): Todo[] => {
  const data = localStorage.getItem("todos");
  return data ? (JSON.parse(data) as Todo[]) : [];
};

/**
 * Save the provided list of todos to the browser's localStorage.
 * The list is stringified as JSON.
 */
export const saveTodos = (todos: Todo[]): void => {
  localStorage.setItem("todos", JSON.stringify(todos));
};
