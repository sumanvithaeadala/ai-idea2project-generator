// src/components/TodoItem.tsx
import React, { useState } from "react";
import { Todo } from "../types";

/**
 * Props for the TodoItem component.
 */
interface TodoItemProps {
  /** The todo object to render */
  todo: Todo;
  /** Called when the completed flag should be toggled */
  onToggle: (id: string) => void;
  /** Called when the todo should be removed */
  onDelete: (id: string) => void;
  /** Called when the todo text is edited */
  onEdit: (id: string, newText: string) => void;
}

/**
 * A single todo item with edit, complete and delete actions.
 */
const TodoItem: React.FC<TodoItemProps> = ({ todo, onToggle, onDelete, onEdit }) => {
  // Local state to control edit mode and the temporary text value.
  const [isEditing, setIsEditing] = useState(false);
  const [editText, setEditText] = useState(todo.text);

  const handleToggle = () => onToggle(todo.id);

  const handleDelete = () => onDelete(todo.id);

  const startEdit = () => {
    setEditText(todo.text); // reset to current text when entering edit mode
    setIsEditing(true);
  };

  const cancelEdit = () => {
    setEditText(todo.text);
    setIsEditing(false);
  };

  const saveEdit = () => {
    const trimmed = editText.trim();
    if (trimmed && trimmed !== todo.text) {
      onEdit(todo.id, trimmed);
    }
    setIsEditing(false);
  };

  return (
    <li className="todo-item" style={{ display: "flex", alignItems: "center", marginBottom: "0.5rem" }}>
      {/* Checkbox to toggle completion */}
      <input
        type="checkbox"
        checked={todo.completed}
        onChange={handleToggle}
        style={{ marginRight: "0.5rem" }}
      />

      {/* Main content – either static text or edit input */}
      {isEditing ? (
        <div style={{ flexGrow: 1, display: "flex", alignItems: "center" }}>
          <input
            type="text"
            value={editText}
            onChange={(e) => setEditText(e.target.value)}
            style={{ flexGrow: 1, marginRight: "0.5rem" }}
          />
          <button onClick={saveEdit} style={{ marginRight: "0.25rem" }}>
            Save
          </button>
          <button onClick={cancelEdit}>Cancel</button>
        </div>
      ) : (
        <span
          className={todo.completed ? "completed" : undefined}
          style={{
            flexGrow: 1,
            textDecoration: todo.completed ? "line-through" : "none",
          }}
        >
          {todo.text}
        </span>
      )}

      {/* Action buttons – edit (if not editing) and delete */}
      {!isEditing && (
        <button onClick={startEdit} style={{ marginLeft: "0.5rem" }}>
          Edit
        </button>
      )}
      <button onClick={handleDelete} style={{ marginLeft: "0.5rem" }}>
        Delete
      </button>
    </li>
  );
};

export default TodoItem;
