// src/components/TodoList.tsx
import React from "react";
import TodoItem from "./TodoItem";
import { Todo } from "../types";

/**
 * Props for the TodoList component.
 */
interface TodoListProps {
  /** List of todos already filtered by the parent component */
  todos: Todo[];
  /** Callback to toggle a todo's completed state */
  onToggle: (id: string) => void;
  /** Callback to delete a todo */
  onDelete: (id: string) => void;
  /** Callback to edit a todo's text */
  onEdit: (id: string, newText: string) => void;
}

/**
 * Renders a list of {@link TodoItem} components. If the list is empty a
 * friendly placeholder is shown.
 */
const TodoList: React.FC<TodoListProps> = ({ todos, onToggle, onDelete, onEdit }) => {
  if (todos.length === 0) {
    return (
      <p style={{ textAlign: "center", color: "#666", marginTop: "2rem" }}>
        No todos to display. Add one above!
      </p>
    );
  }

  return (
    <ul style={{ listStyle: "none", padding: 0 }}>
      {todos.map((todo) => (
        <TodoItem
          key={todo.id}
          todo={todo}
          onToggle={onToggle}
          onDelete={onDelete}
          onEdit={onEdit}
        />
      ))}
    </ul>
  );
};

export default TodoList;
