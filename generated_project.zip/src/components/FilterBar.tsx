// src/components/FilterBar.tsx
import React from "react";
import { Filter } from "../types";

/**
 * Props for the FilterBar component.
 */
interface FilterBarProps {
  /** Currently selected filter */
  currentFilter: Filter;
  /** Callback invoked when a filter button is clicked */
  onChange: (filter: Filter) => void;
}

/**
 * Renders three filter buttons – All, Active and Completed.
 * The button that corresponds to {@link currentFilter} receives a visual
 * highlight (bold text and an underline). Clicking a button triggers
 * {@link onChange} with the appropriate filter value.
 */
const FilterBar: React.FC<FilterBarProps> = ({ currentFilter, onChange }) => {
  // Helper to generate a button for a given filter value.
  const renderButton = (label: string, value: Filter) => {
    const isActive = currentFilter === value;
    const buttonStyle: React.CSSProperties = {
      cursor: "pointer",
      padding: "0.5rem 1rem",
      marginRight: "0.5rem",
      border: "none",
      background: "transparent",
      fontWeight: isActive ? "bold" : "normal",
      textDecoration: isActive ? "underline" : "none",
    };
    return (
      <button
        key={value}
        type="button"
        onClick={() => onChange(value)}
        style={buttonStyle}
        aria-pressed={isActive}
      >
        {label}
      </button>
    );
  };

  return (
    <div style={{ marginTop: "1rem", textAlign: "center" }}>
      {renderButton("All", "all")}
      {renderButton("Active", "active")}
      {renderButton("Completed", "completed")}
    </div>
  );
};

export default FilterBar;
