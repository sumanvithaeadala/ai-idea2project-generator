// Types and interfaces shared across the application

/**
 * Represents a single todo item.
 */
export interface Todo {
  /**
   * Unique identifier for the todo.
   */
  id: string;
  /**
   * The text description of the todo.
   */
  text: string;
  /**
   * Completion status of the todo.
   */
  completed: boolean;
}

/**
 * Filter options for displaying todos.
 */
export type Filter = 'all' | 'active' | 'completed';
