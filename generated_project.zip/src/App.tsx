import React, { useState, useEffect } from "react";

// Child components (assumed to exist in the same directory)
import AddTodo from "./AddTodo";
import TodoList from "./TodoList";
import FilterBar from "./FilterBar";

// Types
import { Todo, Filter } from "./types";

// Local storage helpers
import { loadTodos, saveTodos } from "./utils/localStorage";

const App: React.FC = () => {
  // Initialise state from localStorage
  const [todos, setTodos] = useState<Todo[]>(loadTodos());
  const [filter, setFilter] = useState<Filter>("all");

  // Persist todos whenever they change
  useEffect(() => {
    saveTodos(todos);
  }, [todos]);

  // Handlers ---------------------------------------------------------------
  const addTodo = (text: string) => {
    const newTodo: Todo = {
      id: Date.now().toString() + Math.random().toString(36).substr(2, 5),
      text,
      completed: false,
    };
    setTodos((prev) => [...prev, newTodo]);
  };

  const editTodo = (id: string, newText: string) => {
    setTodos((prev) =>
      prev.map((todo) => (todo.id === id ? { ...todo, text: newText } : todo))
    );
  };

  const toggleComplete = (id: string) => {
    setTodos((prev) =>
      prev.map((todo) =>
        todo.id === id ? { ...todo, completed: !todo.completed } : todo
      )
    );
  };

  const deleteTodo = (id: string) => {
    setTodos((prev) => prev.filter((todo) => todo.id !== id));
  };

  const clearCompleted = () => {
    setTodos((prev) => prev.filter((todo) => !todo.completed));
  };

  // Compute filtered list based on current filter
  const filteredTodos = todos.filter((todo) => {
    if (filter === "all") return true;
    if (filter === "active") return !todo.completed;
    if (filter === "completed") return todo.completed;
    return true;
  });

  return (
    <div className="app-container" style={{ maxWidth: "600px", margin: "0 auto" }}>
      <header>
        <h1>Todo App</h1>
      </header>
      <AddTodo onAdd={addTodo} />
      <TodoList
        todos={filteredTodos}
        onEdit={editTodo}
        onToggle={toggleComplete}
        onDelete={deleteTodo}
      />
      <FilterBar currentFilter={filter} onChange={setFilter} />
      <button onClick={clearCompleted} style={{ marginTop: "1rem" }}>
        Clear Completed
      </button>
    </div>
  );
};

export default App;
