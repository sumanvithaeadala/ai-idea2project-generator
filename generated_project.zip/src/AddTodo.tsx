import React, { useState } from 'react';

// Props definition for the AddTodo component
interface AddTodoProps {
  /**
   * Callback invoked when a new todo text is submitted.
   * The component ensures the text is trimmed and non‑empty before calling.
   */
  onAdd: (text: string) => void;
}

/**
 * AddTodo – a small form that lets the user type a todo and add it to the list.
 *
 * The component maintains its own input state (`input`) and clears it after a
 * successful submission. It forwards the trimmed text to the `onAdd` prop.
 */
const AddTodo: React.FC<AddTodoProps> = ({ onAdd }) => {
  // Internal state for the controlled input element
  const [input, setInput] = useState('');

  // Handles form submission (button click or Enter key)
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault(); // Prevent page reload
    const trimmed = input.trim();
    if (trimmed) {
      onAdd(trimmed);
      setInput(''); // Reset the input field
    }
  };

  return (
    <form className="add-todo" onSubmit={handleSubmit} style={{ marginBottom: '1rem' }}>
      <input
        type="text"
        value={input}
        onChange={(e) => setInput(e.target.value)}
        placeholder="What needs to be done?"
        className="add-todo-input"
        style={{ width: '80%', marginRight: '0.5rem' }}
      />
      <button type="submit" className="add-todo-button">
        Add
      </button>
    </form>
  );
};

export default AddTodo;
