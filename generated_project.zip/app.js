// app.js
// Core Calculator implementation for the Colorful Calculator UI.
// This script is loaded directly in the browser (non‑module), so the Calculator
// class is attached to the global `window` object for external access.

/**
 * Calculator class handling basic arithmetic operations and UI updates.
 *
 * Private fields (using modern # syntax):
 *   #currentInput   – string representing the number being entered.
 *   #previousValue  – number storing the left‑hand operand.
 *   #operator       – string identifier of the pending operation (add, sub, mul, div) or null.
 *   #displayElement – HTMLElement where the calculator display is rendered.
 *   #error          – boolean flag indicating an error state.
 */
class Calculator {
  // Private fields
  #currentInput = "";   // e.g. "12.3"
  #previousValue = null; // number
  #operator = null;      // "add" | "sub" | "mul" | "div" | null
  #displayElement = null;
  #error = false;        // true when an error (e.g., division by zero) is active

  /**
   * Creates a new Calculator instance.
   * @param {HTMLElement} displayElement – Element that shows the current value.
   */
  constructor(displayElement) {
    if (!(displayElement instanceof HTMLElement)) {
      throw new Error("Calculator requires a valid HTMLElement for display");
    }
    this.#displayElement = displayElement;
    this.clear(); // initialise display
  }

  /**
   * Centralised error handling – sets the display to a message and marks the
   * calculator as being in an error state. Subsequent input is ignored until
   * `clear()` is invoked.
   * @param {string} message – Message to display (e.g., "Error").
   */
  handleError(message) {
    this.#error = true;
    this.#currentInput = message;
    this.#previousValue = null;
    this.#operator = null;
    this.updateDisplay();
  }

  /**
   * Append a digit (or decimal point) to the current input.
   * @param {string} digit – Single character: "0"‑"9" or ".".
   */
  appendDigit(digit) {
    // Ignore input while an error is displayed.
    if (this.#error) return;

    if (typeof digit !== "string" || digit.length !== 1) return;
    const isDigit = /[0-9]/.test(digit);
    const isDecimal = digit === ".";
    if (!isDigit && !isDecimal) return;

    // Prevent multiple leading zeros like "00" unless a decimal follows.
    if (isDigit) {
      if (this.#currentInput === "0" && digit === "0") return; // keep single zero
      if (this.#currentInput === "0" && digit !== "0" && !this.#currentInput.includes(".")) {
        // Replace leading zero with new digit (e.g., "0" + "5" => "5")
        this.#currentInput = digit;
        this.updateDisplay();
        return;
      }
    }

    // Allow only one decimal point.
    if (isDecimal && this.#currentInput.includes(".")) return;

    // Append digit.
    this.#currentInput += digit;

    // Truncate very long inputs to keep UI manageable (max 12 characters).
    const MAX_LENGTH = 12;
    if (this.#currentInput.length > MAX_LENGTH) {
      // Keep the most recent characters – typical calculator behaviour.
      this.#currentInput = this.#currentInput.slice(-MAX_LENGTH);
    }

    this.updateDisplay();
  }

  /**
   * Set the pending operator and store the current input as the previous value.
   * @param {string} op – One of "add", "sub", "mul", "div".
   */
  setOperator(op) {
    // Ignore operator changes while an error is active.
    if (this.#error) return;

    if (!["add", "sub", "mul", "div"].includes(op)) return;
    // If there is already a pending operation and a current input, calculate first.
    if (this.#operator && this.#currentInput !== "") {
      this.calculate();
    }
    // Store the current input as previous value.
    const parsed = parseFloat(this.#currentInput);
    this.#previousValue = isNaN(parsed) ? 0 : parsed;
    this.#operator = op;
    this.#currentInput = "";
  }

  /**
   * Execute the stored operation using previousValue and currentInput.
   * The result becomes the new current input for further chaining.
   */
  calculate() {
    // If an error is already displayed, ignore further calculations.
    if (this.#error) return;

    if (!this.#operator) return; // nothing to do
    const right = parseFloat(this.#currentInput);
    const left = this.#previousValue !== null ? this.#previousValue : 0;
    const rhs = isNaN(right) ? 0 : right;
    let result;

    // Explicit division‑by‑zero detection (covers both stored strings and numeric zero).
    if ((this.#operator === "div" || this.#operator === "/") && rhs === 0) {
      this.handleError("Error");
      return;
    }

    switch (this.#operator) {
      case "add":
        result = left + rhs;
        break;
      case "sub":
        result = left - rhs;
        break;
      case "mul":
        result = left * rhs;
        break;
      case "div":
        result = left / rhs;
        break;
      default:
        return;
    }
    // Store result for further operations.
    this.#currentInput = String(result);
    this.#previousValue = null;
    this.#operator = null;
    this.updateDisplay();
  }

  /**
   * Reset the calculator to its initial state.
   */
  clear() {
    this.#currentInput = "";
    this.#previousValue = null;
    this.#operator = null;
    this.#error = false; // clear any error flag
    this.updateDisplay();
  }

  /**
   * Remove the last character from the current input.
   */
  backspace() {
    if (this.#error) return; // do not modify while error is shown
    if (this.#currentInput.length > 0) {
      this.#currentInput = this.#currentInput.slice(0, -1);
    }
    this.updateDisplay();
  }

  /**
   * Update the attached display element with the appropriate value.
   */
  updateDisplay() {
    // Determine what to show: current input, previous value (when no input), or 0.
    let toShow = "0";
    if (this.#currentInput !== "") {
      toShow = this.#currentInput;
    } else if (this.#previousValue !== null) {
      toShow = String(this.#previousValue);
    }
    this.#displayElement.textContent = toShow;
  }
}

// Expose the class globally for the rest of the application.
window.Calculator = Calculator;

/**
 * Initialise the calculator UI by wiring up DOM event listeners.
 * This function can be called on `DOMContentLoaded`.
 */
function initCalculator() {
  // Grab required elements.
  const display = document.getElementById('calc-display');
  const buttons = document.getElementById('calc-buttons');

  if (!display || !buttons) {
    console.warn('Calculator UI elements not found');
    return;
  }

  // Create calculator instance.
  const calc = new Calculator(display);

  // Event delegation for button clicks.
  buttons.addEventListener('click', (e) => {
    const btn = e.target.closest('button');
    if (!btn) return;
    const action = btn.dataset.action;
    const value = btn.dataset.value;

    // Digits (including decimal point) are identified by a data-value attribute without a data-action.
    if (value && !action) {
      calc.appendDigit(value);
      calc.updateDisplay();
      return;
    }

    switch (action) {
      case 'add':
        calc.setOperator('add');
        break;
      case 'sub':
        calc.setOperator('sub');
        break;
      case 'mul':
        calc.setOperator('mul');
        break;
      case 'div':
        calc.setOperator('div');
        break;
      case 'clear':
        calc.clear();
        break;
      case 'backspace':
        calc.backspace();
        break;
      case 'equals':
        calc.calculate();
        break;
      default:
        // No recognised action – ignore.
        return;
    }
    // Ensure display reflects the latest state.
    calc.updateDisplay();
  });

  // Keyboard support: map keys to calculator actions.
  const keyMap = {
    '0': '0', '1': '1', '2': '2', '3': '3', '4': '4', '5': '5',
    '6': '6', '7': '7', '8': '8', '9': '9', '.': '.',
    '+': 'add', '-': 'sub', '*': 'mul', '/': 'div',
    'Enter': 'equals', 'Backspace': 'backspace', 'Escape': 'clear'
  };

  document.addEventListener('keydown', (e) => {
    const key = e.key;
    if (!Object.prototype.hasOwnProperty.call(keyMap, key)) {
      return; // Not a handled key.
    }
    e.preventDefault();
    const action = keyMap[key];
    if (['0','1','2','3','4','5','6','7','8','9','.'].includes(action)) {
      calc.appendDigit(action);
    } else if (['add','sub','mul','div'].includes(action)) {
      calc.setOperator(action);
    } else if (action === 'equals') {
      calc.calculate();
    } else if (action === 'clear') {
      calc.clear();
    } else if (action === 'backspace') {
      calc.backspace();
    }
    calc.updateDisplay();
  });
}

// Export the initializer for external use (e.g., called from HTML on DOMContentLoaded).
window.initCalculator = initCalculator;

document.addEventListener('DOMContentLoaded', initCalculator);
