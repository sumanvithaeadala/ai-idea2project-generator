// Core Calculator implementation and UI binding
// -------------------------------------------------
// This script defines a Calculator class that manages the state of a simple
// arithmetic calculator and connects it to the DOM defined in index.html.
// It also adds keyboard support and basic error handling (division by zero).

// -----------------------------------------------------------------------------
// DOM element references (as required by the task description)
const display = document.getElementById('display');
// Select all calculator buttons. The HTML does not currently assign a
// `.calc-button` class, so we also include any button with a `data-action`
// attribute to ensure all functional buttons are captured.
const buttons = document.querySelectorAll('.calc-button, button[data-action]');

// -----------------------------------------------------------------------------
// Calculator class definition
class Calculator {
  /**
   * Initializes a new calculator instance.
   * currentInput – the string currently being entered (e.g., "12.3")
   * previousValue – the numeric value stored before an operator is chosen
   * operator – one of '+', '-', '*', '/' or null when no operator is pending
   * resetNext – flag indicating that the next digit entry should start a new
   *             number (used after an operator or a calculation).
   */
  constructor() {
    this.currentInput = '';
    this.previousValue = null;
    this.operator = null;
    this.resetNext = false;
    this.updateDisplay();
  }

  /** Append a digit or decimal point to the current input. */
  appendDigit(digit) {
    if (this.resetNext) {
      this.currentInput = '';
      this.resetNext = false;
    }
    // Prevent multiple decimal points
    if (digit === '.' && this.currentInput.includes('.')) return;
    // Allow leading zeroes (the display will show them) – they are harmless.
    this.currentInput += digit;
    this.updateDisplay();
  }

  /** Set the operator (+, -, *, /). If an operator is already pending, compute first. */
  setOperator(op) {
    // Guard against calling without a number entered yet
    if (this.currentInput === '' && this.previousValue === null) return;

    // If we already have a pending operation and the user selects another
    // operator without pressing equals, compute the intermediate result first.
    if (this.operator && !this.resetNext) {
      this.calculate();
    }

    // Store the current number as the previous value (if any)
    if (this.currentInput !== '') {
      this.previousValue = parseFloat(this.currentInput);
    }
    this.operator = op;
    this.resetNext = true; // next digit starts a fresh number
  }

  /** Perform the calculation based on the stored operator and values. */
  calculate() {
    // Need both an operator and a current number to compute
    if (!this.operator || this.currentInput === '' || this.previousValue === null) {
      return;
    }
    const current = parseFloat(this.currentInput);
    let result;
    switch (this.operator) {
      case '+':
        result = this.previousValue + current;
        break;
      case '-':
        result = this.previousValue - current;
        break;
      case '*':
        result = this.previousValue * current;
        break;
      case '/':
        // Division by zero – show error and reset state
        if (current === 0) {
          this.displayError();
          return;
        }
        result = this.previousValue / current;
        break;
      default:
        return;
    }
    // Store result as the new current input for further operations
    this.currentInput = result.toString();
    this.previousValue = null;
    this.operator = null;
    this.resetNext = true;
    this.updateDisplay();
  }

  /** Clear the calculator to its initial state. */
  clear() {
    this.currentInput = '';
    this.previousValue = null;
    this.operator = null;
    this.resetNext = false;
    this.updateDisplay();
  }

  /** Remove the last character from the current input. */
  backspace() {
    if (this.resetNext) {
      // If we are waiting for a new number, treat backspace as clearing.
      this.currentInput = '';
      this.resetNext = false;
    } else {
      this.currentInput = this.currentInput.slice(0, -1);
    }
    this.updateDisplay();
  }

  /** Update the visual display element with the current input or a fallback. */
  updateDisplay() {
    if (!display) return;
    // Show the current input if present; otherwise show the stored previous value
    // or default to "0".
    const text = this.currentInput || (this.previousValue !== null ? this.previousValue.toString() : '0');
    // The display is an <input> element, so we set its value.
    display.value = text;
  }

  /** Show an error message and reset the calculator state. */
  displayError() {
    if (display) display.value = 'Error';
    // Reset after a short delay to allow the user to see the message.
    setTimeout(() => this.clear(), 1500);
  }
}

// Expose the class globally for testing or external use.
window.Calculator = Calculator;

// -----------------------------------------------------------------------------
// Instantiate the calculator
const calc = new Calculator();

// -----------------------------------------------------------------------------
// Button click handling
function handleButtonClick(event) {
  const button = event.currentTarget;
  const action = button.dataset.action;

  if (!action) return;

  if (action === 'digit') {
    // Digit buttons store the actual character in data-value (e.g., "7" or ".")
    const digit = button.dataset.value;
    if (digit !== undefined) {
      calc.appendDigit(digit);
    }
  } else if (['add', 'subtract', 'multiply', 'divide'].includes(action)) {
    const opMap = {
      add: '+',
      subtract: '-',
      multiply: '*',
      divide: '/',
    };
    calc.setOperator(opMap[action]);
  } else if (action === 'equals') {
    calc.calculate();
  } else if (action === 'clear') {
    calc.clear();
  } else if (action === 'backspace') {
    calc.backspace();
  }
  // Each method already updates the display.
}

// Attach click listeners to all identified buttons.
buttons.forEach(btn => btn.addEventListener('click', handleButtonClick));

// -----------------------------------------------------------------------------
// Keyboard support
function handleKeyPress(event) {
  const { key } = event;

  // Digits and decimal point
  if ((key >= '0' && key <= '9') || key === '.') {
    event.preventDefault();
    calc.appendDigit(key);
    return;
  }

  // Operators
  if (['+', '-', '*', '/'].includes(key)) {
    event.preventDefault();
    calc.setOperator(key);
    return;
  }

  // Enter / equals
  if (key === 'Enter' || key === '=') {
    event.preventDefault();
    calc.calculate();
    return;
  }

  // Backspace
  if (key === 'Backspace') {
    event.preventDefault();
    calc.backspace();
    return;
  }

  // Escape – clear
  if (key === 'Escape') {
    event.preventDefault();
    calc.clear();
    return;
  }
}

document.addEventListener('keydown', handleKeyPress);

// Ensure the display shows the initial state on load.
calc.updateDisplay();
