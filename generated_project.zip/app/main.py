"""FastAPI application entry point.

Provides a simple in‑memory CRUD API with CORS enabled and a health check.
"""

from fastapi import FastAPI, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Extra
import uvicorn

# Pydantic models for request bodies. They allow arbitrary fields.
class ItemCreate(BaseModel):
    class Config:
        extra = Extra.allow  # accept any additional fields

class ItemUpdate(BaseModel):
    class Config:
        extra = Extra.allow

# Application instance
app = FastAPI(
    title="Sample FastAPI CRUD Service",
    version="0.1.0",
    description="A minimal FastAPI application exposing health check and CRUD endpoints for demonstration purposes.",
)

# CORS configuration – allow all origins, credentials, methods, and headers
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# In‑memory store for items
items: dict[int, dict] = {}
_next_id: int = 1

# Health check endpoint
@app.get("/health", response_model=dict, status_code=status.HTTP_200_OK)
def health_check():
    """Simple health‑check endpoint used by monitoring tools."""
    return {"status": "ok"}

# CRUD endpoints
@app.get("/items/{item_id}", response_model=dict, status_code=status.HTTP_200_OK)
def read_item(item_id: int):
    """Retrieve an item by its identifier.

    Raises:
        HTTPException: If the item does not exist.
    """
    if item_id not in items:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Item not found")
    return items[item_id]

@app.post("/items/", response_model=dict, status_code=status.HTTP_201_CREATED)
def create_item(item: ItemCreate):
    """Create a new item and store it in memory.

    Returns the created item including its generated ``id``.
    """
    global _next_id
    item_data = item.dict()
    item_data["id"] = _next_id
    items[_next_id] = item_data
    _next_id += 1
    return item_data

@app.put("/items/{item_id}", response_model=dict, status_code=status.HTTP_200_OK)
def update_item(item_id: int, item: ItemUpdate):
    """Update an existing item.

    Raises:
        HTTPException: If the item does not exist.
    """
    if item_id not in items:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Item not found")
    updated_data = item.dict()
    # Preserve the original id
    updated_data["id"] = item_id
    items[item_id] = updated_data
    return updated_data

@app.delete("/items/{item_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_item(item_id: int):
    """Delete an item from the store.

    Raises:
        HTTPException: If the item does not exist.
    """
    if item_id not in items:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Item not found")
    del items[item_id]
    # FastAPI will automatically return a response with status 204 and no body.
    return None

# Export the FastAPI instance for external imports (e.g., uvicorn)
__all__ = ["app"]

# Development entry point
if __name__ == "__main__":
    uvicorn.run("app.main:app", host="0.0.0.0", port=8000, reload=True)
