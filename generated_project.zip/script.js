// Calculator Engine and UI binding
// Implements core calculator logic and connects it to the DOM and keyboard.

// Step A – Core Calculator Engine
class CalculatorEngine {
  constructor() {
    this.clear();
  }

  // Reset all properties to initial state
  clear() {
    this.currentValue = '';
    this.previousValue = '';
    this.operator = null;
    this.shouldResetDisplay = false;
  }

  // Append a digit or decimal point to the current value
  appendNumber(num) {
    // If we need to reset display (after an operator was chosen), start fresh
    if (this.shouldResetDisplay) {
      this.currentValue = '';
      this.shouldResetDisplay = false;
    }
    // Prevent multiple leading zeros (except when after decimal point)
    if (num === '0' && this.currentValue === '0') return;
    // Handle decimal point – allow only one per number
    if (num === '.') {
      if (this.currentValue.includes('.')) return;
      if (this.currentValue === '' || this.currentValue === '-') {
        // If starting a new number, prepend a zero
        this.currentValue += '0';
      }
    }
    this.currentValue += num;
  }

  // Choose an operator (+, -, *, /) and prepare for next number
  chooseOperator(op) {
    // If there's already a pending operation, compute it first
    if (this.operator && !this.shouldResetDisplay) {
      this.compute();
    }
    this.operator = op;
    this.previousValue = this.currentValue || '0';
    this.shouldResetDisplay = true;
  }

  // Compute the result based on stored operator and values
  compute() {
    const prev = parseFloat(this.previousValue);
    const current = parseFloat(this.currentValue);
    if (isNaN(prev) || isNaN(current)) return '';
    let result;
    switch (this.operator) {
      case 'add':
        result = prev + current;
        break;
      case 'subtract':
        result = prev - current;
        break;
      case 'multiply':
        result = prev * current;
        break;
      case 'divide':
        // Handle division by zero gracefully
        result = current === 0 ? 'Error' : prev / current;
        break;
      default:
        return this.currentValue;
    }
    // Convert result to string, handling Error case
    const resultStr = typeof result === 'number' ? result.toString() : result;
    // After computation, reset for next input
    this.currentValue = resultStr;
    this.previousValue = '';
    this.operator = null;
    this.shouldResetDisplay = true;
    return resultStr;
  }

  // Delete the last character from the current value
  delete() {
    if (this.shouldResetDisplay) {
      // If display is flagged to reset, treat as clearing current value
      this.currentValue = '';
      this.shouldResetDisplay = false;
      return;
    }
    this.currentValue = this.currentValue.toString().slice(0, -1);
  }
}

// Export to global scope for external access
window.CalculatorEngine = CalculatorEngine;

// Step B – UI Binding
document.addEventListener('DOMContentLoaded', () => {
  const engine = new CalculatorEngine();
  const display = document.getElementById('display');
  const buttons = document.querySelectorAll('.btn');

  const updateDisplay = () => {
    display.textContent = engine.currentValue || '0';
  };

  buttons.forEach(button => {
    button.addEventListener('click', () => {
      const number = button.dataset.number;
      const action = button.dataset.action;

      if (number !== undefined) {
        engine.appendNumber(number);
      } else if (action) {
        switch (action) {
          case 'decimal':
            engine.appendNumber('.');
            break;
          case 'add':
          case 'subtract':
          case 'multiply':
          case 'divide':
            engine.chooseOperator(action);
            break;
          case 'equals':
            const result = engine.compute();
            engine.currentValue = result;
            break;
          case 'clear':
            engine.clear();
            break;
          case 'delete':
            engine.delete();
            break;
          default:
            // No other actions expected
            break;
        }
      }
      updateDisplay();
    });
  });

  // Step C – Keyboard Support
  const keyToOperator = {
    '+': 'add',
    '-': 'subtract',
    '*': 'multiply',
    '/': 'divide'
  };

  document.addEventListener('keydown', e => {
    const { key } = e;
    if ((key >= '0' && key <= '9') || key === '.') {
      e.preventDefault();
      engine.appendNumber(key);
    } else if (key in keyToOperator) {
      e.preventDefault();
      engine.chooseOperator(keyToOperator[key]);
    } else if (key === 'Enter' || key === '=') {
      e.preventDefault();
      const result = engine.compute();
      engine.currentValue = result;
    } else if (key === 'Backspace') {
      e.preventDefault();
      engine.delete();
    } else if (key === 'Escape') {
      e.preventDefault();
      engine.clear();
    }
    updateDisplay();
  });
});
