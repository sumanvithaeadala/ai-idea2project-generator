// Core calculator logic and UI interaction
// This script is loaded with `defer` in index.html, ensuring the DOM is ready.

// Reference DOM elements
const display = document.getElementById('display');
const buttons = document.querySelectorAll('.btn');

/**
 * Calculator class encapsulating the state and behavior of the calculator.
 */
class Calculator {
  constructor() {
    // The number currently being entered as a string (e.g., "12.3")
    this.currentInput = '';
    // The stored previous value (as a number) when an operator is chosen
    this.previousValue = null; // null indicates no stored value yet
    // The pending operator ('+', '-', '*', '/') or null when none
    this.operator = null;
    // Cache the display element for quick updates
    this.displayElement = display;
    this.updateDisplay();
  }

  /** Append a digit or decimal point to the current input. */
  appendDigit(digit) {
    if (digit === '.' && this.currentInput.includes('.')) return; // single decimal point only
    this.currentInput += digit;
  }

  /** Store the current input as the previous value and set the operator. */
  setOperator(op) {
    // If there is no current input but we already have a previous value, just change operator
    if (this.currentInput === '' && this.previousValue !== null) {
      this.operator = op;
      return;
    }
    // Guard against empty input when no previous value exists
    if (this.currentInput === '') return;
    const parsed = parseFloat(this.currentInput);
    if (isNaN(parsed)) return; // invalid number
    this.previousValue = parsed;
    this.operator = op;
    this.currentInput = '';
  }

  /** Perform the pending calculation and update the display. */
  calculate() {
    if (this.operator === null || this.previousValue === null || this.currentInput === '') {
      this._showError();
      return;
    }
    const current = parseFloat(this.currentInput);
    if (isNaN(current)) {
      this._showError();
      return;
    }
    let result;
    switch (this.operator) {
      case '+':
        result = this.previousValue + current;
        break;
      case '-':
        result = this.previousValue - current;
        break;
      case '*':
        result = this.previousValue * current;
        break;
      case '/':
        if (current === 0) {
          this._showError();
          return;
        }
        result = this.previousValue / current;
        break;
      default:
        this._showError();
        return;
    }
    // Reset state with the result as the new current input
    this.currentInput = result.toString();
    this.previousValue = null;
    this.operator = null;
  }

  /** Clear all state and reset the display. */
  clear() {
    this.currentInput = '';
    this.previousValue = null;
    this.operator = null;
    this.updateDisplay();
  }

  /** Remove the last character from the current input. */
  backspace() {
    if (this.currentInput.length > 0) {
      this.currentInput = this.currentInput.slice(0, -1);
    }
  }

  /** Update the calculator's display element. */
  updateDisplay() {
    if (!this.displayElement) return;
    // Show the current input if present, otherwise the stored previous value, or 0.
    const value = this.currentInput || (this.previousValue !== null ? this.previousValue.toString() : '0');
    this.displayElement.value = value;
  }

  /** Internal helper to display an error message. */
  _showError() {
    if (this.displayElement) this.displayElement.value = 'Error';
    // Preserve error state in currentInput so subsequent updateDisplay calls keep it.
    this.currentInput = '';
    this.previousValue = null;
    this.operator = null;
  }
}

// Instantiate the calculator
const calc = new Calculator();

// Attach click listeners to all buttons
buttons.forEach(btn => {
  btn.addEventListener('click', () => {
    const action = btn.dataset.action;
    const text = btn.innerText.trim();

    if (action === 'number' || (!action && /[0-9.]/.test(text))) {
      calc.appendDigit(text);
    } else if (action === 'add') {
      calc.setOperator('+');
    } else if (action === 'subtract') {
      calc.setOperator('-');
    } else if (action === 'multiply') {
      calc.setOperator('*');
    } else if (action === 'divide') {
      calc.setOperator('/');
    } else if (action === 'equals') {
      calc.calculate();
    } else if (action === 'clear') {
      calc.clear();
    } else if (action === 'backspace') {
      calc.backspace();
    }
    // After handling the action, update the display.
    calc.updateDisplay();
  });
});

// Keyboard support
const keyMap = {
  '0': '0',
  '1': '1',
  '2': '2',
  '3': '3',
  '4': '4',
  '5': '5',
  '6': '6',
  '7': '7',
  '8': '8',
  '9': '9',
  '.': '.',
  '+': 'add',
  '-': 'subtract',
  '*': 'multiply',
  '/': 'divide',
  'Enter': 'equals',
  '=': 'equals',
  'Backspace': 'backspace',
  'Escape': 'clear'
};

function isOperator(key) {
  return ['add', 'subtract', 'multiply', 'divide'].includes(key);
}

// Map operator actions to actual symbols used by Calculator.setOperator
const operatorSymbolMap = {
  add: '+',
  subtract: '-',
  multiply: '*',
  divide: '/'
};

document.addEventListener('keydown', (e) => {
  const mapped = keyMap[e.key];
  if (!mapped) return; // not a handled key

  if (/^[0-9.]$/.test(mapped)) {
    calc.appendDigit(mapped);
  } else if (isOperator(mapped)) {
    calc.setOperator(operatorSymbolMap[mapped]);
  } else if (mapped === 'equals') {
    calc.calculate();
  } else if (mapped === 'clear') {
    calc.clear();
  } else if (mapped === 'backspace') {
    calc.backspace();
  }

  calc.updateDisplay();
  e.preventDefault();
});

// Export the calculator instance for debugging purposes
window.calculator = calc;
